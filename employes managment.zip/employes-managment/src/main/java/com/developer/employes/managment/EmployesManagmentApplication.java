package com.developer.employes.managment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployesManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployesManagmentApplication.class, args);
	}

}
