package com.developer.employes.managment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployesManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
